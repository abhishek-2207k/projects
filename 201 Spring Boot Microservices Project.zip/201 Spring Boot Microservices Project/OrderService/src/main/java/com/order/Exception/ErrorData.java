package com.order.Exception;

public class ErrorData {
 private String message;

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}
 
}

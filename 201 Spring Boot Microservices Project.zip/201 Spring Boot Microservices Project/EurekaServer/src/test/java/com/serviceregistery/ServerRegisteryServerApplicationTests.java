package com.serviceregistery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegisteryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

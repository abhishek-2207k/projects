package com.restaraunt.exception;

public class MenuItemException extends Exception{

    public MenuItemException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

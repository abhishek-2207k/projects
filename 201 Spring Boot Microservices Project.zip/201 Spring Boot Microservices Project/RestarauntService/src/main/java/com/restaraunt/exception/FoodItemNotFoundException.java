package com.restaraunt.exception;

public class FoodItemNotFoundException extends Exception {

    public FoodItemNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

package com.restaraunt.exception;

public class BudgetException extends Exception{

    public BudgetException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

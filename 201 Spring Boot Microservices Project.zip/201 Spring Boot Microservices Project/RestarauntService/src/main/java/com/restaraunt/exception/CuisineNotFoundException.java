package com.restaraunt.exception;

public class CuisineNotFoundException extends Exception{

    public CuisineNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

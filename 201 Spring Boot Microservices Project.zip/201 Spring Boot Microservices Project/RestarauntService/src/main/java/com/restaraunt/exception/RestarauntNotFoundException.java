package com.restaraunt.exception;

public class RestarauntNotFoundException extends Exception{

    public RestarauntNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

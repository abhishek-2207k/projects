package com.restaraunt.exception;

public class DistanceException extends Exception{

    public DistanceException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

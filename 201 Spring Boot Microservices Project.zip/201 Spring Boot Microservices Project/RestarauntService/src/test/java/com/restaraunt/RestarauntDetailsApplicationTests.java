package com.restaraunt;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.restaraunt.repositories.MenuRepo;
import com.restaraunt.service.MenuServiceImpl;

@SpringBootTest
class RestarauntDetailsApplicationTests {

    
    
	@Test
	void contextLoads() {
	}

}
